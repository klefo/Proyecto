package crm.benedicto.excepciones;

public class LogicaException extends Exception {

    public LogicaException() {
    }

    public LogicaException(String msg) {
        super(msg);
    }
}
