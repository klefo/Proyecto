
package crm.benedicto.excepciones;

public class UsuarioException extends Exception {

    public UsuarioException() {
    }

    public UsuarioException(String msg) {
        super(msg);
    }
}
