/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crm.benedicto.excepciones;

/**
 *
 * @author Hugo Cornejo
 */
public class BusinessException extends Exception {

    public BusinessException(String message) {
        super(message);
    }       
}
