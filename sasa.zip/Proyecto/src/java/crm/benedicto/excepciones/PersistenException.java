package crm.benedicto.excepciones;

public class PersistenException extends Exception {

    public PersistenException() {
    }
    
    public PersistenException(String msg) {
        super(msg);
    }
}
