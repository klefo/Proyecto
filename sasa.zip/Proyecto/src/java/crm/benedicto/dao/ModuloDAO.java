package crm.benedicto.dao;

/**
 *
 * @author Richard Chavez
 */
public class ModuloDAO {
    
    
    
}
