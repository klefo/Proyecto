package crm.benedicto.dao;
import java.sql.*;

public class RolDAO {    
    Connection conexion;
    
    public RolDAO(Connection conexion){
        this.conexion = conexion;
    }
    
    
}
