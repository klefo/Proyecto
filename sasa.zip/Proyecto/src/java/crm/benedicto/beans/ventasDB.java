/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crm.benedicto.beans;

/**
 *
 * @author YICELA
 */
public class ventasDB {
    private String id = "0";
    private ventasDB database = null;
}

//public ventasDB(){
//
//}
