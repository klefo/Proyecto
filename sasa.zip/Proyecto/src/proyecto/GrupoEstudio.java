package proyecto;


public class GrupoEstudio {

    public GrupoEstudio () {
    }

}

