package proyecto;


public class Ventas {

    private Cliente mCliente;

    public Ventas () {
    }

    public Cliente getCliente () {
        return mCliente;
    }

    public void setCliente (Cliente val) {
        this.mCliente = val;
    }

}

