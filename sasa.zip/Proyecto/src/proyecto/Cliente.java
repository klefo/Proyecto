package proyecto;


public class Cliente {

    private int Codigo;

    public Cliente () {
    }

    public int getCodigo () {
        return Codigo;
    }

    public void setCodigo (int val) {
        this.Codigo = val;
    }

}

