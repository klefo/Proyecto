package proyecto;


public class Prospecto extends Persona {

    
    public Prospecto () {
    }

}

