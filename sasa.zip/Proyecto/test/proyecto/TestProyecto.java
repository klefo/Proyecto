/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author Encalada
 */
public class TestProyecto {
    
    public TestProyecto() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
}
